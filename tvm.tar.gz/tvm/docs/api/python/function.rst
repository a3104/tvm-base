tvm.Function
------------
.. autoclass:: tvm.Function

.. autofunction:: tvm.register_func

.. autofunction:: tvm.get_global_func
