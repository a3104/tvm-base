tvm.intrin
----------
.. automodule:: tvm.intrin

.. autosummary::

   tvm.call_packed
   tvm.call_pure_intrin
   tvm.call_pure_extern
   tvm.register_intrin_rule
   tvm.exp
   tvm.log


.. autofunction:: tvm.call_packed
.. autofunction:: tvm.call_pure_intrin
.. autofunction:: tvm.call_pure_extern
.. autofunction:: tvm.register_intrin_rule
.. autofunction:: tvm.exp
.. autofunction:: tvm.log
