tvm.module
----------
.. automodule:: tvm.module
    :members:
