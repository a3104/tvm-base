nnvm.top
--------
.. automodule:: nnvm.top

.. autofunction:: register_compute

.. autofunction:: register_schedule

.. autofunction:: register_pattern


.. autoclass:: nnvm.top.AttrDict
   :members:
