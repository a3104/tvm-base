tvm.contrib.rpc
---------------
.. automodule:: tvm.contrib.rpc

.. autofunction:: tvm.contrib.rpc.connect
.. autofunction:: tvm.contrib.rpc.connect_tracker

.. autoclass:: tvm.contrib.rpc.TrackerSession
    :members:
    :inherited-members:

.. autoclass:: tvm.contrib.rpc.RPCSession
    :members:
    :inherited-members:

.. autoclass:: tvm.contrib.rpc.LocalSession
    :members:
    :inherited-members:

.. autoclass:: tvm.contrib.rpc.Server
    :members:
    :inherited-members:
