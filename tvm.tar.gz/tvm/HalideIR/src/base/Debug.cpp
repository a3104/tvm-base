#include "Debug.h"

namespace HalideIR {
namespace Internal {

int debug::debug_level() {
    return 0;
}

}
}
